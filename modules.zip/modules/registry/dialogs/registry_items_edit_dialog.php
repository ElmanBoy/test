<?php
include_once $_SERVER['DOCUMENT_ROOT'] . '/modules/registry/dialogs/registry_items_edit.php';