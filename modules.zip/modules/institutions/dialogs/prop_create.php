<?php
include_once $_SERVER['DOCUMENT_ROOT'].'/modules/registry/props/dialogs/registry_create.php';