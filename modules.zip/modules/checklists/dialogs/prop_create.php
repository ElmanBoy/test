<?php
include_once $_SERVER['DOCUMENT_ROOT'].'/modules/checklists/items/dialogs/prop_create.php';