<?php
include_once $_SERVER['DOCUMENT_ROOT'] . '/modules/registry/props/ajaxHandlers/getFieldsFromDB.php';
