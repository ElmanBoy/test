<?php
use \Core\Gui;
use \Core\Db;
use \Core\Registry;
use Core\Templates;

require_once $_SERVER['DOCUMENT_ROOT'] . '/core/connect.php';
$db = new Db;
$tmpl = new Templates();

