<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/core/ajaxHandlers/getDocTemplate.php';

